# Handoff: Light Theme + Theme Toggle

## Overview
Add a light color theme to the existing dark-themed site, plus a header toggle button (sun/moon) letting users switch between dark and light, persisted across visits.

## About the Design Files
The bundled HTML files are **design references** built as static prototypes — not production code to copy directly. Recreate this behavior in the target codebase's actual stack (React/Vue/plain JS — whichever the project already uses), following its existing component and state patterns.

## Fidelity
High-fidelity. Exact colors, spacing, and toggle placement shown are final; typography/layout for existing dark-theme elements is unchanged.

## What changed vs the original dark site
1. All hardcoded dark colors were converted to CSS custom properties so both themes can share one stylesheet:
   - `--bg`, `--bg-rgb`, `--surface`, `--border`, `--text`, `--muted`, `--accent`, `--accent-rgb`, `--accent-dim`
2. Two token sets, switched by a `data-theme` attribute on `<html>`:
   - `[data-theme="light"]` (default): bg #ffffff, surface #f6f6f7, border rgba(0,0,0,0.08), text #14181b, muted rgba(20,24,27,0.62), accent #0d9488
   - `[data-theme="dark"]`: bg #0a0a0a, surface #111111, border rgba(255,255,255,0.08), text #f0ede8, muted rgba(240,237,232,0.72), accent #00d4c8
3. A round toggle button (`.theme-toggle`, 36×36px, circular, 1px border) placed in the nav, to the left of the mobile burger button. Shows a sun icon in light mode, a moon icon in dark mode (CSS toggles `.icon-sun`/`.icon-moon` visibility via `[data-theme="dark"]`).
4. Click handler on the toggle: flips `data-theme` between `light`/`dark`, writes the choice to `localStorage.theme`, and swaps the logo `<img>` src (see Assets).
5. Canvas-drawn particle/line effects (hero background) read the accent color from `--accent-rgb` at runtime instead of a hardcoded RGB literal, so they recolor with the theme.
6. `body`, `nav`, `footer`, `.service-card`, `.card-front` get a 0.35s color/background/border-color transition for a smooth theme switch.

## Components

### Theme toggle button
- Position: nav bar, right side, immediately left of `.nav-cta` / mobile burger
- Size: 36×36px circle, `border: 1px solid var(--border)`, transparent background
- Icon: 17×17px inline SVG, `color: var(--muted)` default, `var(--accent)` on hover (border also turns accent on hover)
- Light mode: sun icon (circle + rays, stroke-based)
- Dark mode: moon icon (crescent, filled)
- `aria-label="Переключить тему оформления"`, `title="Светлая / тёмная тема"`

## Interactions & Behavior
- Click toggles theme instantly (no page reload), animates existing colored surfaces over 0.35s
- Theme choice persists via `localStorage` key `theme` (`"light"` | `"dark"`); on load, stored value overrides the default (`light`)
- Logo image swaps: `images/logo-light.svg` (light theme) ↔ `images/logo.svg` (dark theme) on both `.nav-logo img` and `.footer-logo img`

## Design Tokens
| Token | Light | Dark |
|---|---|---|
| --bg | #ffffff | #0a0a0a |
| --surface | #f6f6f7 | #111111 |
| --border | rgba(0,0,0,0.08) | rgba(255,255,255,0.08) |
| --text | #14181b | #f0ede8 |
| --muted | rgba(20,24,27,0.62) | rgba(240,237,232,0.72) |
| --accent | #0d9488 | #00d4c8 |
| --accent-dim | rgba(accent-rgb,0.12) | rgba(accent-rgb,0.12) |

## Assets
- `images/logo.svg` — dark-theme logo (teal #00d4c8 + cream #f0ede8 on transparent/dark bg)
- `images/logo-light.svg` — light-theme logo, same geometry, ink color swapped to #14181b, teal accents unchanged
- Sun/moon icons are inline SVG in the toggle button markup (no external asset)

## Files
- `light-white.html` — full site with light theme applied as default + toggle wired to dark
- `index-dark.html` — original dark-only version, for diffing what changed
- `images/logo.svg`, `images/logo-light.svg`
